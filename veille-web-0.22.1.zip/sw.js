// Iriscope 0.22.1 : hors ligne
const APP = 'vl-app-0.22.1', TILES = 'vl-tuiles-v1';
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('vl-app-') && k !== APP).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.hostname === 'data.geopf.fr' && u.pathname.startsWith('/wmts') && /PLANIGNV2/.test(u.search)) {
    e.respondWith(caches.open(TILES).then(c => c.match(r.url).then(hit => hit || fetch(r).then(res => { if (res.ok || res.type === 'opaque') c.put(r.url, res.clone()); return res; }))));
    return;
  }
  if (u.origin !== self.location.origin) return;
  e.respondWith(fetch(r).then(res => { if (res.ok) { const copy = res.clone(); caches.open(APP).then(c => c.put(r, copy)); } return res; })
    .catch(() => caches.match(r).then(hit => hit || (r.mode === 'navigate' ? caches.match('/veille-web/') : Promise.reject(new Error('hors ligne'))))));
});
